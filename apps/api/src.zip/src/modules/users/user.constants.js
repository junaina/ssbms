export const ROLES = {
  ADMIN: "ADMIN",
  PROVIDER: "PROVIDER",
  CUSTOMER: "CUSTOMER",
};
export const ALL_ROLES = Object.values(ROLES);
